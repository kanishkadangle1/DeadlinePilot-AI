import React, { useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { 
  Compass, 
  LayoutDashboard, 
  Calendar, 
  Sparkles, 
  LogOut, 
  Menu, 
  X, 
  ChevronRight,
  TrendingUp,
  BrainCircuit
} from "lucide-react";

interface DashboardLayoutProps {
  children: React.ReactNode;
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export default function DashboardLayout({ children, activeTab, setActiveTab }: DashboardLayoutProps) {
  const navigate = useNavigate();
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);

  const menuItems = [
    { id: "tasks", label: "Tasks & Milestones", icon: LayoutDashboard },
    { id: "planner", label: "Sprint Planner", icon: Calendar, badge: "Upcoming" },
    { id: "coach", label: "AI Copilot Coach", icon: BrainCircuit, badge: "Smart" },
  ];

  const handleLogout = () => {
    navigate("/");
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 font-sans flex flex-col md:flex-row">
      
      {/* Mobile Header */}
      <header className="md:hidden bg-white border-b border-slate-200 h-16 px-4 flex items-center justify-between sticky top-0 z-50">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 bg-blue-600 rounded-xl flex items-center justify-center text-white shadow-md shadow-blue-500/10">
            <Compass className="w-5 h-5" />
          </div>
          <span className="text-lg font-black text-slate-900 tracking-tight font-display flex items-center gap-1">
            DeadlinePilot <span className="text-[9px] bg-blue-50 text-blue-700 font-extrabold px-2 py-0.5 rounded-full uppercase border border-blue-200/50"><Sparkles className="w-2.5 h-2.5 inline" /> AI</span>
          </span>
        </div>
        <button 
          onClick={() => setIsMobileSidebarOpen(!isMobileSidebarOpen)}
          className="p-2 text-slate-600 hover:bg-slate-100 rounded-lg"
          aria-label="Toggle Menu"
        >
          {isMobileSidebarOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </button>
      </header>

      {/* Mobile Sidebar Overlay */}
      {isMobileSidebarOpen && (
        <div 
          className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs z-40 md:hidden"
          onClick={() => setIsMobileSidebarOpen(false)}
        ></div>
      )}

      {/* Navigation Sidebar (Desktop & Mobile) */}
      <aside className={`
        fixed inset-y-0 left-0 w-64 bg-white border-r border-slate-200 z-50 transform transition-transform duration-300 md:translate-x-0 md:static md:h-screen flex flex-col justify-between
        ${isMobileSidebarOpen ? "translate-x-0" : "-translate-x-full"}
      `}>
        <div>
          {/* Sidebar Header (Hidden on Mobile) */}
          <div className="hidden md:flex h-16 px-6 items-center gap-3 border-b border-slate-100">
            <div className="w-9 h-9 bg-blue-600 rounded-xl flex items-center justify-center text-white shadow-md shadow-blue-500/10">
              <Compass className="w-5 h-5" />
            </div>
            <div>
              <span className="text-base font-black text-slate-900 tracking-tight font-display flex items-center gap-1">
                DeadlinePilot <span className="text-[8px] bg-blue-50 text-blue-700 font-extrabold px-1.5 py-0.5 rounded-full uppercase tracking-wider border border-blue-200/50"><Sparkles className="w-2 h-2 inline" /> AI</span>
              </span>
              <p className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider">Timeline Copilot</p>
            </div>
          </div>

          {/* Sidebar Navigation Items */}
          <nav className="p-4 space-y-1.5">
            <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider px-3 mb-2">
              Pilot Navigation
            </div>
            {menuItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    setActiveTab(item.id);
                    setIsMobileSidebarOpen(false);
                  }}
                  className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-150 cursor-pointer ${
                    isActive 
                      ? "bg-blue-50 text-blue-700 font-semibold border border-blue-100/50" 
                      : "text-slate-600 hover:text-slate-900 hover:bg-slate-50"
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <Icon className={`w-4.5 h-4.5 ${isActive ? "text-blue-600" : "text-slate-400"}`} />
                    <span>{item.label}</span>
                  </div>
                  {item.badge ? (
                    <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded-full uppercase tracking-wider ${
                      item.badge === "Smart" 
                        ? "bg-amber-100 text-amber-800" 
                        : "bg-slate-100 text-slate-500"
                    }`}>
                      {item.badge}
                    </span>
                  ) : (
                    <ChevronRight className={`w-4 h-4 text-slate-300 transition-transform ${isActive ? "rotate-90 text-blue-500" : ""}`} />
                  )}
                </button>
              );
            })}
          </nav>
        </div>

        {/* Sidebar Footer Details */}
        <div className="p-4 border-t border-slate-100">
          <div className="bg-slate-50 rounded-xl p-3 mb-4 border border-slate-100/80">
            <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-700">
              <TrendingUp className="w-3.5 h-3.5 text-blue-600" />
              Pilot Score Widget
            </div>
            <div className="flex items-baseline gap-1 mt-1">
              <span className="text-xl font-black text-slate-900">84</span>
              <span className="text-[10px] text-slate-400">/ 100 PTS</span>
            </div>
            <p className="text-[10px] text-slate-400 mt-1">Good speed. Watch design debt creep!</p>
          </div>

          <button
            onClick={handleLogout}
            className="w-full flex items-center gap-2.5 px-3 py-2 text-sm font-medium text-slate-500 hover:text-red-600 hover:bg-red-50 rounded-xl transition-all cursor-pointer"
          >
            <LogOut className="w-4.5 h-4.5" />
            <span>Sign Out</span>
          </button>
        </div>
      </aside>

      {/* Main Panel Content Area */}
      <div className="flex-grow flex flex-col overflow-y-auto md:h-screen">
        {children}
      </div>

    </div>
  );
}
