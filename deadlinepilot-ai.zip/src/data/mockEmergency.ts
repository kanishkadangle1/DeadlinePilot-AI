export interface AIEmergencyResponse {
  mode: "EMERGENCY";
  priorityTasks: string[];
  removedTasks: string[];
  actionPlan: string[];
  urgencyMessage: string;
}

export const mockEmergencyResponse: AIEmergencyResponse = {
  mode: "EMERGENCY",
  priorityTasks: [
    "Finalize high impact presentation video clips",
    "Deploy backend container build and secure ingress paths"
  ],
  removedTasks: [
    "Polishing custom font pairings and layout adjustments",
    "Constructing optional multilingual translation APIs"
  ],
  actionPlan: [
    "Focus only on critical path tasks (Core functionality)",
    "Skip non-essential styling, animations, or advanced metrics",
    "Reduce feature scope to minimum viable submission standards immediately"
  ],
  urgencyMessage: "CRITICAL ALERT: You are running out of time! Standard roadmap flow is suspended. Focus 100% of available momentum on your video presentation and live container deployment."
};

/**
 * Simulates retrieving Emergency Action guidelines
 */
export function simulateEmergencyMode(tasksTitleList: string[]): Promise<AIEmergencyResponse> {
  return new Promise((resolve) => {
    setTimeout(() => {
      // Find high priority pending items to focus on
      const highPriority = tasksTitleList.slice(0, 2);
      resolve({
        mode: "EMERGENCY",
        priorityTasks: highPriority.length > 0 ? highPriority : ["Finalize production-build deployment checks", "Complete presentation slide recordings"],
        removedTasks: [
          "Polishing auxiliary responsive components",
          "Secondary chat prompt optimizations"
        ],
        actionPlan: [
          "Focus only on critical path tasks",
          "Skip non-essential features",
          "Reduce scope to minimum viable submission"
        ],
        urgencyMessage: "You are running out of time. Focus only on submission-critical tasks."
      });
    }, 1200); // 1.2s delay for system calculation look
  });
}
