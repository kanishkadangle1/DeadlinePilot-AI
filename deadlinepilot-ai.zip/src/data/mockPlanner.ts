export interface AIDayPlan {
  schedule: {
    morning: string[];
    afternoon: string[];
    evening: string[];
  };
  reasoning: string;
  estimatedProductivityScore: number;
}

export const mockPlannerResponses: Record<string, AIDayPlan> = {
  "on_track": {
    schedule: {
      morning: [
        "Focus Hour: Configure Firebase security rules and initialize schemas (Sam)",
        "Review Session: Synchronize layout parameters with frontend"
      ],
      afternoon: [
        "Development Session: Deploy express proxy to Google Cloud Run (Jordan)",
        "Review session: Draft pitch templates (Taylor)"
      ],
      evening: [
        "Code check-in & verification test run",
        "Record 15-second sandbox test clips for the presentation video"
      ]
    },
    reasoning: "High-priority database configuration is scheduled during morning peak focus hours. Afternoon is allocated for DevOps and initial slide outlines, leaving lighter validation checks for the evening.",
    estimatedProductivityScore: 88
  },
  "high_risk": {
    schedule: {
      morning: [
        "URGENT: Clear outstanding Firebase credentials error block",
        "Refactoring: Standardize TypeScript relative import structures"
      ],
      afternoon: [
        "Deploy backend express container to Cloud Run (High risk checkpoint)",
        "Merge active git branch pull requests"
      ],
      evening: [
        "Polish dashboard bento style properties",
        "Write 2-minute pitch audio voice-over draft"
      ]
    },
    reasoning: "Severe authentication blockages require early intervention. Development tasks are isolated to the afternoon, and creative presentation writing is deferred to a relaxed evening flow.",
    estimatedProductivityScore: 74
  },
  "light_work": {
    schedule: {
      morning: [
        "Draft and review slide templates (Taylor)",
        "Polishing visual margins and border-radius layouts"
      ],
      afternoon: [
        "Record high-resolution sandbox terminal interaction clips",
        "Trim presentation audio and edit video timelines"
      ],
      evening: [
        "Check overall code-style compliance and run production build tests",
        "Prepare final submission files and URLs"
      ]
    },
    reasoning: "All critical development tasks have been resolved. The focus shifts entirely to presentation and video recording, ensuring a polished, stress-free submission process.",
    estimatedProductivityScore: 92
  }
};

/**
 * Simulates an AI call to organize tasks into Morning, Afternoon, and Evening schedule chunks
 */
export function simulateAIDailyPlan(pendingTasksCount: number, highPriorityCount: number, totalHours: number): Promise<AIDayPlan> {
  return new Promise((resolve) => {
    setTimeout(() => {
      if (highPriorityCount > 1) {
        // High Risk profile
        resolve({
          schedule: {
            morning: [
              "Focus Block: Standardize the remaining High Priority task objectives immediately",
              "Review Session: Check local state management for memory leak risks"
            ],
            afternoon: [
              "Development Block: Complete pending features and intermediate milestones",
              "Team Stand-up: Direct task reallocation to unblock bottlenecks"
            ],
            evening: [
              "Draft slide content script",
              "Execute full local production build testing"
            ]
          },
          reasoning: `You have ${highPriorityCount} outstanding High Priority items. We scheduled these intensive blocks in the morning to maximize focus during your ${totalHours}-hour workspace window.`,
          estimatedProductivityScore: 79
        });
      } else if (pendingTasksCount > 0) {
        // Standard On Track profile
        resolve({
          schedule: {
            morning: [
              "Focus Block: Complete primary development tasks",
              "Integration Session: Check endpoints alignment with mock interfaces"
            ],
            afternoon: [
              "Asset Preparation: Outline slide templates and presentation voice-over",
              "Refactoring: Verify responsive CSS classes across mobile screens"
            ],
            evening: [
              "Complete lighter design polishes",
              "Verify dev build is fully compiled"
            ]
          },
          reasoning: `Perfect task distribution across your scheduled ${totalHours} hours. Outstanding ${pendingTasksCount} tasks are neatly split into high-energy morning slots and creative afternoon modules.`,
          estimatedProductivityScore: 86
        });
      } else {
        // Finished light profile
        resolve(mockPlannerResponses["light_work"]);
      }
    }, 1400); // Realistic 1.4s delay for AI thinking feel
  });
}
