export interface AISmartReplan {
  updatedSchedule: {
    morning: string[];
    afternoon: string[];
    evening: string[];
  };
  changes: string[];
  riskLevel: "Low" | "Medium" | "High";
  reasoning: string;
}

export const mockReplannerResponses: Record<string, AISmartReplan> = {
  "on_risk": {
    updatedSchedule: {
      morning: [
        "URGENT: Address outstanding high priority blocker tasks immediately",
        "Integration Session: Sync frontend layouts with main controller"
      ],
      afternoon: [
        "Development: Complete remaining core features (Rescheduled from morning)",
        "Review session: Slide deck outline and script creation (Compressed)"
      ],
      evening: [
        "Lighter tasks: Optional CSS polishes (Moved or deferred to tomorrow)",
        "Build Check: Final verification compile run"
      ]
    },
    changes: [
      "Core feature development moved from morning to afternoon due to high priority blockers.",
      "Optional layout polishes deprioritized and deferred to preserve timeline safety.",
      "Pitch deck preparation compressed into a single 1-hour block."
    ],
    riskLevel: "Medium",
    reasoning: "High priority tasks have been pinned to the morning session to ensure they get completed. Non-essential design enhancements are pushed down to keep the critical path clear."
  },
  "critical": {
    updatedSchedule: {
      morning: [
        "CRITICAL: Emergency troubleshooting of high risk dependencies",
        "Focus: Core MVC backend routing and verification"
      ],
      afternoon: [
        "Emergency sprint: Primary feature adjustments (Shifted from yesterday)",
        "Review: High impact demo video storyboard draft"
      ],
      evening: [
        "Lighter review: Pitch deck final checks (Deferred optional presentation polish)",
        "System Check: Ingress validation logs check"
      ]
    },
    changes: [
      "Secondary animations and mock API integrations suspended indefinitely.",
      "Emergency troubleshooting of database setup scheduled first thing in the morning.",
      "Slide deck styling deferred entirely to focus on backend telemetry."
    ],
    riskLevel: "High",
    reasoning: "Due to multiple outstanding high priority objectives, we have suspended secondary aesthetic tasks and consolidated your focus onto core functionality to prevent missing the deadline."
  },
  "nominal": {
    updatedSchedule: {
      morning: [
        "Focus Hour: General task board cleanups",
        "Development: Secondary integrations and polishing"
      ],
      afternoon: [
        "Slide deck layout compilation and storyboard review",
        "High quality video pitch recording"
      ],
      evening: [
        "Production build execution and portal submissions check",
        "Celebration / Buffer time"
      ]
    },
    changes: [
      "All high priority tasks are already complete or on track.",
      "Buffer time inserted in the evening to absorb any unexpected last-minute issues."
    ],
    riskLevel: "Low",
    reasoning: "Your progress is excellent. Minimal adjustments needed—the planner simply inserted a safety buffer in the evening to guarantee an on-time submit."
  }
};

/**
 * Simulates a Smart Adaptive Re-planning computation
 */
export function simulateAISmartReplan(
  pendingTasksCount: number,
  highPriorityCount: number,
  hasDelayedOrMissedTasks: boolean
): Promise<AISmartReplan> {
  return new Promise((resolve) => {
    setTimeout(() => {
      if (highPriorityCount > 1 || hasDelayedOrMissedTasks) {
        if (highPriorityCount >= 3) {
          resolve(mockReplannerResponses["critical"]);
        } else {
          resolve(mockReplannerResponses["on_risk"]);
        }
      } else {
        resolve(mockReplannerResponses["nominal"]);
      }
    }, 1500); // 1.5 seconds simulated execution delay
  });
}
