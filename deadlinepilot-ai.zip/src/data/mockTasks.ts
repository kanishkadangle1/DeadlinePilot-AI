export interface MockTask {
  id: string;
  title: string;
  priority: "High" | "Medium" | "Low";
  status: "Pending" | "In Progress" | "Done" | "Delayed" | "Missed";
  deadline: string;
  category: "Frontend" | "Backend" | "Design" | "Pitch";
  assignee: string;
  subtasksCount: number;
  completedSubtasksCount: number;
}

export const initialMockTasks: MockTask[] = [
  {
    id: "task-1",
    title: "Configure Firebase security rules and initialize Firestore schemas",
    priority: "High",
    status: "In Progress",
    deadline: "2 hours left",
    category: "Backend",
    assignee: "Sam (Backend)",
    subtasksCount: 3,
    completedSubtasksCount: 1,
  },
  {
    id: "task-2",
    title: "Build the interactive multi-page React components and layouts",
    priority: "High",
    status: "Done",
    deadline: "Completed",
    category: "Frontend",
    assignee: "Alex (Frontend)",
    subtasksCount: 4,
    completedSubtasksCount: 4,
  },
  {
    id: "task-3",
    title: "Deploy express proxy backend to Google Cloud Run container",
    priority: "High",
    status: "Pending",
    deadline: "5 hours left",
    category: "Backend",
    assignee: "Jordan (DevOps)",
    subtasksCount: 2,
    completedSubtasksCount: 0,
  },
  {
    id: "task-4",
    title: "Create pitch slide template and record 2-minute video prototype",
    priority: "Medium",
    status: "Pending",
    deadline: "12 hours left",
    category: "Pitch",
    assignee: "Taylor (Product)",
    subtasksCount: 5,
    completedSubtasksCount: 1,
  },
  {
    id: "task-5",
    title: "Develop custom Tailwind premium UI style theme assets",
    priority: "Low",
    status: "Done",
    deadline: "Completed",
    category: "Design",
    assignee: "Alex (Frontend)",
    subtasksCount: 2,
    completedSubtasksCount: 2,
  }
];

export interface AISuggestion {
  id: string;
  type: "warning" | "tip" | "info";
  message: string;
  impact: string;
}

export const mockAISuggestions: AISuggestion[] = [
  {
    id: "s-1",
    type: "warning",
    message: "Deploy express proxy is blocking frontend key features. Prioritize backend deployment.",
    impact: "Saves 2 hours of blocked integration time"
  },
  {
    id: "s-2",
    type: "tip",
    message: "Split 'Create pitch slide template' into smaller milestone steps to keep team cadence fast.",
    impact: "Reduces last-minute delivery risk by 35%"
  },
  {
    id: "s-3",
    type: "info",
    message: "Project speed is currently at 84%. Team velocity is stable but watch for feature creep.",
    impact: "Guarantees on-time prototype submission"
  }
];
