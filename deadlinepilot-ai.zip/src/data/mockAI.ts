export interface AIBreakdownResult {
  task: string;
  breakdown: string[];
  estimatedDays: number;
  priorityPlan: string;
}

export const mockAIBreakdowns: Record<string, AIBreakdownResult> = {
  "complete dsa sheet": {
    task: "Complete DSA Sheet",
    breakdown: [
      "Arrays & Strings (Sliding Window, Two Pointers)",
      "Linked List (Reversal, Cycle Detection)",
      "Stacks & Queues (Monotonic, Implementation)",
      "Trees & Binary Search Trees (DFS, BFS traversals)",
      "Graphs & Traversals (Dijkstra's, MST algorithms)",
      "Dynamic Programming (Knapsack, Grid paths)"
    ],
    estimatedDays: 7,
    priorityPlan: "Start with Arrays & Strings for quick momentum, then allocate 2 solid days for Graphs and Dynamic Programming."
  },
  "build backend auth": {
    task: "Build Backend Auth",
    breakdown: [
      "Setup Express middleware & body parser",
      "Initialize Firebase Admin SDK & client auth",
      "Configure Firestore authentication security rules",
      "Implement route protection token check middleware",
      "Add login/logout API test endpoints"
    ],
    estimatedDays: 1,
    priorityPlan: "Setup firestore.rules first. Secure authentication endpoints before connecting frontend states."
  },
  "record project presentation": {
    task: "Record Project Presentation",
    breakdown: [
      "Draft 5-slide pitch structure",
      "Write high-impact 2-minute recording script",
      "Execute terminal live coding walk-through tests",
      "Record full screen screen-cast demo",
      "Polish audio voice-over and trim video timeline"
    ],
    estimatedDays: 1,
    priorityPlan: "Draft the screen-play script first to prevent stumbling on video. Keep final edit strictly under 120 seconds."
  },
  "design tailwind dashboard theme": {
    task: "Design Tailwind Dashboard Theme",
    breakdown: [
      "Configure custom font families (Inter, Space Grotesk)",
      "Define clean high-contrast light and dark gray colors",
      "Design interactive state animations using framer motion",
      "Build modular reusable UI wrapper components",
      "Check contrast metrics for high access compliance"
    ],
    estimatedDays: 2,
    priorityPlan: "Stabilize index.css font styles first, then construct individual responsive bento components."
  },
  "default": {
    task: "Custom Hackathon Epic Task",
    breakdown: [
      "Define initial task boundaries & inputs",
      "Draft modular pseudo-code flowcharts",
      "Build basic layout & scaffolding framework code",
      "Run local endpoint integration & unit tests",
      "Polishing style properties and submit feedback logs"
    ],
    estimatedDays: 3,
    priorityPlan: "Break down execution to 3 clean mini-milestones. Do not work on secondary animations until basic data displays."
  }
};

/**
 * Simulates a delay and fetches a structured task breakdown
 */
export function getSimulatedTaskBreakdown(inputTask: string): Promise<AIBreakdownResult> {
  return new Promise((resolve) => {
    setTimeout(() => {
      const normalized = inputTask.toLowerCase().trim();
      
      // Match close matches
      if (normalized.includes("dsa") || normalized.includes("sheet")) {
        resolve(mockAIBreakdowns["complete dsa sheet"]);
      } else if (normalized.includes("auth") || normalized.includes("backend")) {
        resolve(mockAIBreakdowns["build backend auth"]);
      } else if (normalized.includes("record") || normalized.includes("presentation") || normalized.includes("pitch")) {
        resolve(mockAIBreakdowns["record project presentation"]);
      } else if (normalized.includes("design") || normalized.includes("theme") || normalized.includes("tailwind")) {
        resolve(mockAIBreakdowns["design tailwind dashboard theme"]);
      } else {
        // Dynamic custom return
        resolve({
          task: inputTask,
          breakdown: [
            `Initialize modular ${inputTask} core module`,
            `Draft responsive user-facing parameters for ${inputTask}`,
            `Connect ${inputTask} logic parameters to active telemetry states`,
            `Polishing edge-case code paths for ${inputTask} validation`,
            `Run full verification tests and complete code submission`
          ],
          estimatedDays: 4,
          priorityPlan: `Focus strictly on establishing basic data structures for '${inputTask}' before adding layout animations.`
        });
      }
    }, 1200); // 1.2 second simulation delay for realism
  });
}
