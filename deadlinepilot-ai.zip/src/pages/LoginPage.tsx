import React from "react";
import { useNavigate } from "react-router-dom";
import { Compass, Key, Sparkles } from "lucide-react";

export default function LoginPage() {
  const navigate = useNavigate();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    // Proceed with navigation to simulate login
    navigate("/dashboard");
  };

  return (
    <div id="login-container" className="min-h-screen flex items-center justify-center bg-slate-50/50 px-4 py-12 sm:px-6 lg:px-8 font-sans">
      <div id="login-card-wrapper" className="max-w-md w-full space-y-8 bg-white p-8 rounded-2xl shadow-[0_8px_30px_rgb(0,0,0,0.04)] border border-slate-200/60 relative overflow-hidden transition-all duration-300 hover:shadow-[0_12px_40px_rgb(0,0,0,0.08)]">
        {/* Decorative ambient gradient circle */}
        <div className="absolute -top-10 -right-10 w-32 h-32 bg-blue-500/10 rounded-full blur-2xl pointer-events-none"></div>
        <div className="absolute -bottom-10 -left-10 w-32 h-32 bg-emerald-500/10 rounded-full blur-2xl pointer-events-none"></div>

        <div className="text-center">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-blue-600 text-white shadow-lg shadow-blue-500/20 mb-5 transform transition-all duration-300 hover:scale-105 hover:rotate-3">
            <Compass className="w-8 h-8 animate-pulse" />
          </div>
          <h1 className="text-3xl font-black text-slate-900 tracking-tight font-display flex items-center justify-center gap-2">
            DeadlinePilot <span className="text-[10px] bg-blue-50 text-blue-700 font-extrabold px-2 py-0.5 rounded-full uppercase tracking-wider flex items-center gap-1 border border-blue-200/50"><Sparkles className="w-2.5 h-2.5" /> AI</span>
          </h1>
          <p className="mt-3 text-sm text-slate-500 leading-relaxed font-medium">
            Intelligent timeline tracking & milestone pilot for hackathon projects.
          </p>
        </div>

        <div className="mt-8 space-y-6">
          <div className="bg-slate-50/70 rounded-xl p-4 border border-slate-200/50">
            <h3 className="text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-2.5 flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5 text-blue-500" />
              Hackathon Companion Features:
            </h3>
            <ul className="text-xs text-slate-600 space-y-2 font-medium">
              <li className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 bg-blue-500 rounded-full"></span>
                Auto-prioritize submissions based on deadlines
              </li>
              <li className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 bg-blue-500 rounded-full"></span>
                Split tasks among team members intelligently
              </li>
              <li className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 bg-blue-500 rounded-full"></span>
                Generates quick deadline countdown alarms
              </li>
              <li className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 bg-blue-500 rounded-full"></span>
                AI-assisted scope manager to prevent feature creep
              </li>
            </ul>
          </div>

          <button
            id="google-signin-btn"
            onClick={handleLogin}
            className="w-full flex justify-center items-center gap-3 px-4 py-3 border border-slate-200 rounded-xl text-sm font-semibold text-slate-700 bg-white hover:bg-slate-50 hover:border-slate-300 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-all duration-250 cursor-pointer shadow-2xs hover:scale-[1.01]"
          >
            <svg className="w-5 h-5" viewBox="0 0 24 24">
              <path
                fill="#EA4335"
                d="M12 5.04c1.66 0 3.2.57 4.38 1.69l3.27-3.27C17.68 1.54 14.98 1 12 1 7.35 1 3.37 3.67 1.39 7.56l3.85 2.99c.9-2.7 3.42-4.51 6.76-4.51z"
              />
              <path
                fill="#4285F4"
                d="M23.49 12.27c0-.81-.07-1.59-.2-2.35H12v4.45h6.44c-.28 1.47-1.11 2.71-2.36 3.55l3.66 2.84c2.14-1.97 3.39-4.88 3.39-8.49z"
              />
              <path
                fill="#FBBC05"
                d="M5.24 14.45c-.23-.69-.36-1.42-.36-2.18s.13-1.49.36-2.18L1.39 7.56C.5 9.35 0 11.35 0 13.5s.5 4.15 1.39 5.94l3.85-2.99z"
              />
              <path
                fill="#34A853"
                d="M12 23c3.24 0 5.97-1.07 7.96-2.91l-3.66-2.84c-1.01.68-2.31 1.08-4.3 1.08-3.34 0-5.86-1.81-6.76-4.51L1.39 16.82C3.37 20.71 7.35 23 12 23z"
              />
            </svg>
            Sign in with Google
          </button>

          <div className="relative flex py-2 items-center">
            <div className="flex-grow border-t border-slate-200"></div>
            <span className="flex-shrink mx-4 text-slate-400 text-xs font-semibold uppercase tracking-wider">Or instant guest sandbox</span>
            <div className="flex-grow border-t border-slate-200"></div>
          </div>

          <button
            id="guest-signin-btn"
            onClick={handleLogin}
            className="w-full flex justify-center items-center gap-2 px-4 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-sm font-bold shadow-sm shadow-blue-500/10 hover:shadow-md hover:shadow-blue-500/20 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-all duration-250 cursor-pointer hover:scale-[1.01]"
          >
            <Key className="w-4 h-4" />
            Enter Sandbox Environment
          </button>
        </div>

        <div className="pt-4 text-center border-t border-slate-100 text-[11px] text-slate-400 font-semibold tracking-wide uppercase">
          Powered by DeadlinePilot AI
        </div>
      </div>
    </div>
  );
}
