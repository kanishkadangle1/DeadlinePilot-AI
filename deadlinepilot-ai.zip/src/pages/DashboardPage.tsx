import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "motion/react";
import DashboardLayout from "../layouts/DashboardLayout";
import { 
  initialMockTasks, 
  mockAISuggestions, 
  MockTask, 
  AISuggestion 
} from "../data/mockTasks";
import { getSimulatedTaskBreakdown, AIBreakdownResult } from "../data/mockAI";
import { simulateAIDailyPlan, AIDayPlan } from "../data/mockPlanner";
import { simulateAISmartReplan, AISmartReplan } from "../data/mockReplanner";
import { simulateEmergencyMode, AIEmergencyResponse } from "../data/mockEmergency";
import { 
  Clock, 
  Plus, 
  Trash2, 
  Sparkles, 
  CheckCircle2, 
  AlertTriangle, 
  TrendingUp, 
  Send, 
  User, 
  Layers,
  CircleDot,
  CalendarDays,
  Flame,
  BrainCircuit,
  Lightbulb,
  CheckSquare,
  ArrowUpRight,
  ShieldAlert,
  ListTodo,
  PieChart,
  Calendar
} from "lucide-react";

export default function DashboardPage() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("tasks");
  const [filter, setFilter] = useState<string>("ALL");
  
  // Standardised Tasks State initialized with the imported mock tasks
  const [tasks, setTasks] = useState<MockTask[]>(initialMockTasks);

  // Form states for creating a new task
  const [newTaskTitle, setNewTaskTitle] = useState("");
  const [newTaskCategory, setNewTaskCategory] = useState<"Frontend" | "Backend" | "Design" | "Pitch">("Frontend");
  const [newTaskPriority, setNewTaskPriority] = useState<"High" | "Medium" | "Low">("Medium");
  const [newTaskAssignee, setNewTaskAssignee] = useState("Alex");
  const [newTaskDeadline, setNewTaskDeadline] = useState("6 hours left");

  // AI Advisor Chat log state
  const [chatInput, setChatInput] = useState("");
  const [chatMessages, setChatMessages] = useState<Array<{ sender: "user" | "bot"; text: string }>>([
    { sender: "bot", text: "Welcome to your AI pilot cockpit! I am ready to evaluate active feature scope, run speed checks, or prepare pitch slide blueprints." },
  ]);

  // Hackathon phases / planner stages
  const [phases, setPhases] = useState([
    { id: "p1", title: "Phase 1: Foundation (Hours 0-12)", status: "Completed", items: ["Design wireframes & system schemas", "Setup repository & dev environment", "Deploy base Express API"] },
    { id: "p2", title: "Phase 2: Core MVP (Hours 12-28)", status: "Active", items: ["Implement Firebase login & key features", "Construct interactive UI layouts", "Bind state managers & responsive flows"] },
    { id: "p3", title: "Phase 3: Integration (Hours 28-36)", status: "Pending", items: ["Connect frontend to backend proxy endpoints", "Perform full end-to-end telemetry testing", "Verify cloud container database ingress"] },
    { id: "p4", title: "Phase 4: Submission (Hours 36-48)", status: "Pending", items: ["Complete pitching slide deck templates", "Record & host 2-minute project demo video", "Submit project portal final links"] },
  ]);

  // AI Task Breakdown feature states
  const [breakdownInput, setBreakdownInput] = useState("");
  const [breakdownResult, setBreakdownResult] = useState<AIBreakdownResult | null>(null);
  const [isBreakingDown, setIsBreakingDown] = useState(false);
  const [breakdownCompletedItems, setBreakdownCompletedItems] = useState<Record<string, boolean>>({});

  const handleAIBreakdown = async (customTask?: string) => {
    const taskToQuery = customTask || breakdownInput;
    if (!taskToQuery.trim()) return;

    setIsBreakingDown(true);
    setBreakdownResult(null);
    setBreakdownCompletedItems({});
    
    try {
      const result = await getSimulatedTaskBreakdown(taskToQuery);
      setBreakdownResult(result);
      setBreakdownInput(result.task);
    } catch (err) {
      console.error(err);
    } finally {
      setIsBreakingDown(false);
    }
  };

  const toggleBreakdownItem = (item: string) => {
    setBreakdownCompletedItems(prev => ({
      ...prev,
      [item]: !prev[item]
    }));
  };

  const handleInjectBreakdown = () => {
    if (!breakdownResult) return;
    
    const newTasks: MockTask[] = breakdownResult.breakdown.map((item, index) => ({
      id: `task-ai-${Date.now()}-${index}`,
      title: item,
      priority: index === 0 ? "High" : "Medium",
      status: "Pending",
      deadline: `${Math.ceil((breakdownResult.estimatedDays * 24) / breakdownResult.breakdown.length)} hours left`,
      category: "Backend",
      assignee: "Alex (AI Draft)",
      subtasksCount: 1,
      completedSubtasksCount: 0,
    }));

    setTasks(prev => [...newTasks, ...prev]);
    
    // Also post helper notification inside AI Advisor Chat log
    setChatMessages(prev => [
      ...prev,
      { sender: "bot", text: `I have successfully injected ${newTasks.length} sub-milestones from '${breakdownResult.task}' directly into your live roadmap task board!` }
    ]);
  };

  // AI Daily Planner states
  const [availableHours, setAvailableHours] = useState<number>(8);
  const [dailyPlanResult, setDailyPlanResult] = useState<AIDayPlan | null>(null);
  const [isPlanning, setIsPlanning] = useState(false);

  // Emergency Mode states
  const [manualEmergency, setManualEmergency] = useState(false);
  const [isEmergencyLoading, setIsEmergencyLoading] = useState(false);
  const [emergencyResponse, setEmergencyResponse] = useState<AIEmergencyResponse | null>(null);

  const isDeadlineWithin4Hours = (deadlineStr: string): boolean => {
    if (!deadlineStr) return false;
    const match = deadlineStr.match(/(\d+)\s*hour/i);
    if (match) {
      const hours = parseInt(match[1], 10);
      return hours <= 4;
    }
    return false;
  };

  const hasUrgentDeadline = tasks.some(t => t.status !== "Done" && isDeadlineWithin4Hours(t.deadline));
  const isEmergencyModeActive = manualEmergency || hasUrgentDeadline;

  useEffect(() => {
    if (isEmergencyModeActive && !emergencyResponse && !isEmergencyLoading) {
      const fetchEmergencyMode = async () => {
        setIsEmergencyLoading(true);
        try {
          const activeTitles = tasks.filter(t => t.status !== "Done" && t.priority === "High").map(t => t.title);
          const res = await simulateEmergencyMode(activeTitles);
          setEmergencyResponse(res);
          setChatMessages(prev => [
            ...prev,
            { 
              sender: "bot", 
              text: `🚨 [EMERGENCY SYSTEM ENGAGED]: Submission deadline is critically close. Focus checklist loaded, auxiliary features temporarily deferred.` 
            }
          ]);
        } catch (e) {
          console.error(e);
        } finally {
          setIsEmergencyLoading(false);
        }
      };
      fetchEmergencyMode();
    } else if (!isEmergencyModeActive && emergencyResponse) {
      setEmergencyResponse(null);
    }
  }, [isEmergencyModeActive, tasks, emergencyResponse, isEmergencyLoading]);

  // Smart Replanning Engine states
  const [replanResult, setReplanResult] = useState<AISmartReplan | null>(null);
  const [isReplanning, setIsReplanning] = useState(false);
  const [showReplanCompare, setShowReplanCompare] = useState(false);
  const [lastReplanTrigger, setLastReplanTrigger] = useState<string>("");

  const handleSmartReplan = async (currentTasksList?: MockTask[], forceTrigger = false) => {
    setIsReplanning(true);
    setReplanResult(null);
    setShowReplanCompare(true);
    
    const targetTasks = currentTasksList || tasks;
    const hasDelayedOrMissed = targetTasks.some(t => t.status === "Delayed" || t.status === "Missed");
    const activePending = targetTasks.filter(t => t.status !== "Done").length;
    const highPriorityCount = targetTasks.filter(t => t.priority === "High" && t.status !== "Done").length;

    try {
      const result = await simulateAISmartReplan(activePending, highPriorityCount, hasDelayedOrMissed || forceTrigger);
      setReplanResult(result);
      setLastReplanTrigger(hasDelayedOrMissed ? "Adaptive Trigger (Delayed/Missed Task detected)" : "Manual Overrule Request");
      
      // Post to AI Advisor chat log
      setChatMessages(prev => [
        ...prev,
        { 
          sender: "bot", 
          text: `🚨 [Smart Replanning Engaged]: Due to task adjustments, I have run an adaptive rescheduling sweep. Risk Level is now rated [${result.riskLevel}]. Review the 'Adaptive Smart Replanning' dashboard panel below!` 
        }
      ]);
    } catch (err) {
      console.error(err);
    } finally {
      setIsReplanning(false);
    }
  };

  const handleGenerateDailyPlan = async () => {
    setIsPlanning(true);
    setDailyPlanResult(null);
    try {
      const activePendingCount = tasks.filter((t) => t.status !== "Done").length;
      const result = await simulateAIDailyPlan(activePendingCount, highPriorityPendingCount, availableHours);
      setDailyPlanResult(result);
      
      // Notify chatbot
      setChatMessages(prev => [
        ...prev,
        { sender: "bot", text: `I've synthesized a customized daily schedule tailored to your available ${availableHours} working hours. Estimated Productivity Score is ${result.estimatedProductivityScore}%. Let's crush this day!` }
      ]);
    } catch (err) {
      console.error(err);
    } finally {
      setIsPlanning(false);
    }
  };

  // Dynamic calculations for Sections A, B and C
  const totalTasks = tasks.length;
  const completedTasks = tasks.filter((t) => t.status === "Done").length;
  const inProgressTasks = tasks.filter((t) => t.status === "In Progress").length;
  const pendingTasks = tasks.filter((t) => t.status === "Pending").length;
  
  const completionRate = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;
  
  // High priority outstanding issues check
  const highPriorityPendingCount = tasks.filter((t) => t.priority === "High" && t.status !== "Done").length;
  const isAtRisk = highPriorityPendingCount > 1;

  // Dynamic focus score based on completion density and priority
  const focusScore = Math.max(10, Math.min(100, Math.round(completionRate * 0.7 + (totalTasks - highPriorityPendingCount) * 5)));
  
  // Real-time ticking countdown (32 hours 14 mins 52 secs initially)
  const [timeLeftStr, setTimeLeftStr] = useState("32:14:52");

  useEffect(() => {
    const timer = setInterval(() => {
      const parts = timeLeftStr.split(":").map(Number);
      let s = parts[2];
      let m = parts[1];
      let h = parts[0];

      s -= 1;
      if (s < 0) {
        s = 59;
        m -= 1;
        if (m < 0) {
          m = 59;
          h -= 1;
          if (h < 0) {
            h = 0;
            m = 0;
            s = 0;
          }
        }
      }

      const hStr = h.toString().padStart(2, "0");
      const mStr = m.toString().padStart(2, "0");
      const sStr = s.toString().padStart(2, "0");
      setTimeLeftStr(`${hStr}:${mStr}:${sStr}`);
    }, 1000);

    return () => clearInterval(timer);
  }, [timeLeftStr]);

  // Change status sequentially: Pending -> In Progress -> Done -> Delayed -> Missed -> Pending
  const cycleTaskStatus = (id: string) => {
    let triggeredReplan = false;
    const updatedTasks = tasks.map((task) => {
      if (task.id === id) {
        let nextStatus: "Pending" | "In Progress" | "Done" | "Delayed" | "Missed" = "Pending";
        if (task.status === "Pending") nextStatus = "In Progress";
        else if (task.status === "In Progress") nextStatus = "Done";
        else if (task.status === "Done") nextStatus = "Delayed";
        else if (task.status === "Delayed") nextStatus = "Missed";
        
        if (nextStatus === "Delayed" || nextStatus === "Missed") {
          triggeredReplan = true;
        }
        return { ...task, status: nextStatus };
      }
      return task;
    });

    setTasks(updatedTasks);

    if (triggeredReplan) {
      handleSmartReplan(updatedTasks, true);
    }
  };

  const handleAddTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTaskTitle.trim()) return;

    const newTask: MockTask = {
      id: "task-" + Date.now().toString(),
      title: newTaskTitle,
      priority: newTaskPriority,
      status: "Pending",
      deadline: newTaskDeadline || "6 hours left",
      category: newTaskCategory,
      assignee: `${newTaskAssignee} (Self)`,
      subtasksCount: 1,
      completedSubtasksCount: 0,
    };

    setTasks([newTask, ...tasks]);
    setNewTaskTitle("");
  };

  const deleteTask = (id: string) => {
    setTasks(tasks.filter((task) => task.id !== id));
  };

  // Submit AI message simulated
  const handleSendChatMessage = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!chatInput.trim()) return;

    const userMsg = chatInput;
    setChatMessages((prev) => [...prev, { sender: "user", text: userMsg }]);
    setChatInput("");

    setTimeout(() => {
      let botResponse = "I have reviewed your request. Once Firebase and Gemini API connections are active, I will calculate this dynamically using your repository metadata. Keep making progress!";
      const lower = userMsg.toLowerCase();
      if (lower.includes("scope") || lower.includes("feature")) {
        botResponse = `Scope Evaluation: Your sprint completion rate is currently ${completionRate}%. High priority backlog stands at ${highPriorityPendingCount} pending tasks. We suggest FREEZING scope and prioritizing the video submission setup.`;
      } else if (lower.includes("estimate") || lower.includes("time") || lower.includes("long")) {
        botResponse = `Sprint Estimation: With ${totalTasks - completedTasks} outstanding tasks, your team has approximately ${Math.round((totalTasks - completedTasks) * 2.5)} hours of design and code work remaining. This fits safely into your ${timeLeftStr.split(':')[0]} hours left!`;
      } else if (lower.includes("slide") || lower.includes("pitch")) {
        botResponse = "Pitch guidance: Present a clean, high-impact 5-slide deck focusing heavily on 1. Problem identification, 2. AI prioritized timelines, 3. Real sandbox test outputs, and 4. Deployment metrics.";
      }

      setChatMessages((prev) => [...prev, { sender: "bot", text: botResponse }]);
    }, 700);
  };

  // Filtering implementation
  const filteredTasks = tasks.filter((task) => {
    if (isEmergencyModeActive && task.priority === "Low") return false;
    
    if (filter === "ALL") return true;
    if (filter === "PENDING") return task.status === "Pending";
    if (filter === "IN_PROGRESS") return task.status === "In Progress";
    if (filter === "COMPLETED") return task.status === "Done";
    if (filter === "HIGH_PRIORITY") return task.priority === "High";
    return true;
  });

  return (
    <DashboardLayout activeTab={activeTab} setActiveTab={setActiveTab}>
      
      {/* Top Header Row inside Dashboard Content */}
      <div className="bg-white border-b border-slate-200 px-6 sm:px-8 py-4 sticky top-0 md:top-0 z-30 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-sm font-bold text-slate-400 uppercase tracking-wider">Workspace Dashboard</h2>
          <div className="flex items-center gap-2 mt-0.5">
            <h1 className="text-xl sm:text-2xl font-black font-display text-slate-900 tracking-tight">
              Welcome back, Pilot
            </h1>
            <span className="text-xs bg-slate-100 text-slate-700 font-medium px-2 py-0.5 rounded-md border border-slate-200 flex items-center gap-1">
              <User className="w-3.5 h-3.5 text-blue-600" /> Alex (Lead)
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1 flex items-center gap-1">
            <Calendar className="w-3.5 h-3.5 text-slate-400" /> Mon, June 30, 2026 • Local Station Live
          </p>
        </div>

        {/* Real-time status indicator */}
        <div className="flex items-center gap-4 flex-wrap">
          <button
            onClick={() => {
              if (isEmergencyModeActive) {
                setManualEmergency(false);
              } else {
                setManualEmergency(true);
              }
            }}
            className={`text-xs font-bold px-3.5 py-2.5 rounded-xl border transition-all cursor-pointer flex items-center gap-1.5 ${
              isEmergencyModeActive
                ? "bg-red-600 hover:bg-red-700 text-white border-red-500 animate-pulse"
                : "bg-slate-100 hover:bg-slate-200 text-slate-700 border-slate-200"
            }`}
          >
            <Flame className="w-3.5 h-3.5" />
            {isEmergencyModeActive ? "Emergency Active" : "Activate Emergency Mode"}
          </button>

          <div className="flex items-center gap-3 bg-slate-50 border border-slate-200/80 rounded-xl p-2.5 px-4">
            <span className="text-xs text-slate-500 font-medium">Pilot Status:</span>
            {isEmergencyModeActive ? (
              <span className="text-xs bg-red-950 text-red-400 font-extrabold px-2.5 py-1 rounded-full border border-red-800 flex items-center gap-1 animate-pulse">
                <ShieldAlert className="w-3.5 h-3.5 text-red-500" /> EMERGENCY
              </span>
            ) : isAtRisk ? (
              <span className="text-xs bg-red-100 text-red-800 font-bold px-2.5 py-1 rounded-full border border-red-200 flex items-center gap-1 animate-pulse">
                <ShieldAlert className="w-3.5 h-3.5 text-red-600" /> AT RISK
              </span>
            ) : (
              <span className="text-xs bg-emerald-100 text-emerald-800 font-bold px-2.5 py-1 rounded-full border border-emerald-200 flex items-center gap-1">
                <TrendingUp className="w-3.5 h-3.5 text-emerald-600" /> ON TRACK
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Main Grid Content Panels */}
      <div className="p-6 sm:p-8 flex-grow space-y-8">
        
        {/* Dynamic Render based on Active tab selection */}
        {activeTab === "tasks" && (
          <motion.div 
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.35, ease: "easeOut" }}
            className={`space-y-8 transition-all duration-500 p-2 rounded-3xl ${
              isEmergencyModeActive 
                ? "bg-slate-950 text-white ring-4 ring-red-500/30 p-4 sm:p-8 shadow-[0_0_60px_rgba(239,68,68,0.2)]" 
                : ""
            }`}
          >
            
            {/* EMERGENCY MODE ACTIVATED RED BANNER */}
            {isEmergencyModeActive && (
              <div className="bg-red-950/90 border-2 border-red-600 rounded-2xl p-6 text-white flex flex-col md:flex-row items-center justify-between gap-6 shadow-2xl relative overflow-hidden animate-fadeIn backdrop-blur-md">
                <div className="absolute top-0 right-0 w-48 h-48 bg-red-600/10 rounded-full blur-3xl pointer-events-none"></div>
                <div className="flex items-center gap-4 relative z-10">
                  <div className="bg-red-600 p-3 rounded-full text-white animate-bounce flex-shrink-0">
                    <Flame className="w-6 h-6 animate-pulse" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-[10px] bg-red-800 text-red-100 font-extrabold px-2.5 py-0.5 rounded-full uppercase tracking-wider animate-pulse">
                        EMERGENCY ACTIVE
                      </span>
                      <span className="text-[11px] font-bold text-red-300">
                        {hasUrgentDeadline ? "Automated Detection: Deadline ≤ 4 Hours" : "Manual Activation"}
                      </span>
                    </div>
                    <h2 className="text-lg font-black tracking-tight font-display text-white mt-1">
                      CRITICAL DEADLINE MODE ENGAGED
                    </h2>
                    <p className="text-xs text-red-200/80 mt-0.5 max-w-xl">
                      Focus mode restricting roadmap to active High/Medium priorities. Low priority features are deferred to maintain project stability.
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-4 relative z-10 flex-shrink-0 w-full md:w-auto justify-between md:justify-end">
                  <div className="bg-black/50 border border-red-500/40 px-5 py-2.5 rounded-xl text-center min-w-[130px]">
                    <span className="text-[9px] text-red-400 font-extrabold uppercase tracking-wider block">TIME REMAINING</span>
                    <span className="text-lg font-black font-mono text-red-500 tracking-widest">{timeLeftStr}</span>
                  </div>
                  <button
                    onClick={() => {
                      setManualEmergency(false);
                      // Reset deadlines to be non-urgent
                      setTasks(prev => prev.map(t => {
                        if (isDeadlineWithin4Hours(t.deadline)) {
                          return { ...t, deadline: "8 hours left" };
                        }
                        return t;
                      }));
                    }}
                    className="bg-white hover:bg-red-50 text-red-950 font-bold px-4 py-2.5 rounded-xl text-xs transition-all cursor-pointer shadow-md uppercase tracking-wider font-sans whitespace-nowrap"
                  >
                    Exit Emergency Mode
                  </button>
                </div>
              </div>
            )}

            {/* AI EMERGENCY WARNING PANEL */}
            {isEmergencyModeActive && (
              <div className="bg-slate-900 border-2 border-red-500/30 rounded-2xl p-6 text-white space-y-6 relative overflow-hidden shadow-2xl animate-fadeIn">
                <div className="absolute top-0 right-0 w-48 h-48 bg-red-600/5 rounded-full blur-3xl pointer-events-none"></div>
                <div className="flex items-center justify-between border-b border-red-500/20 pb-4">
                  <div className="flex items-center gap-2">
                    <ShieldAlert className="w-5 h-5 text-red-500 animate-pulse" />
                    <div>
                      <h3 className="text-sm font-extrabold uppercase tracking-widest text-slate-100 font-sans">
                        AI Emergency Workload Assessment
                      </h3>
                      <p className="text-[11px] text-slate-400">Adaptive workload reduction logic activated under heavy constraints</p>
                    </div>
                  </div>
                  <span className="text-[10px] bg-red-500/20 text-red-300 font-black px-2.5 py-1 rounded-full uppercase tracking-wider">
                    Scope Frozen
                  </span>
                </div>

                {isEmergencyLoading ? (
                  <div className="py-10 text-center space-y-3">
                    <div className="w-8 h-8 border-2 border-red-500/30 border-t-red-500 rounded-full animate-spin mx-auto"></div>
                    <p className="text-xs font-semibold text-slate-400">Synthesizing scope reduction directives...</p>
                  </div>
                ) : (
                  emergencyResponse && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      
                      {/* Action plan & warning */}
                      <div className="space-y-4">
                        <div className="bg-red-950/30 border border-red-500/20 p-4 rounded-xl">
                          <p className="text-xs text-red-300 font-semibold leading-relaxed">
                            {emergencyResponse.urgencyMessage}
                          </p>
                        </div>

                        <div className="space-y-2">
                          <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1">
                            <Sparkles className="w-3.5 h-3.5 text-red-400" />
                            AI Action Directives
                          </h4>
                          <div className="space-y-2">
                            {emergencyResponse.actionPlan.map((act, idx) => (
                              <div key={idx} className="flex items-start gap-2.5 text-xs text-slate-200">
                                <span className="text-red-500 font-extrabold mt-0.5">•</span>
                                <p className="leading-relaxed font-medium">{act}</p>
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>

                      {/* Priorities list side-by-side */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div className="bg-slate-950 border border-slate-800 p-4 rounded-xl space-y-2.5">
                          <h5 className="text-[10px] font-bold text-emerald-400 uppercase tracking-widest border-b border-slate-800/80 pb-1.5 flex items-center gap-1.5">
                            <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-pulse"></span>
                            Priority Focus Path
                          </h5>
                          <div className="space-y-2">
                            {emergencyResponse.priorityTasks.map((t, idx) => (
                              <div key={idx} className="bg-emerald-950/20 border border-emerald-900/30 p-2.5 rounded-lg text-xs font-semibold text-slate-100 leading-relaxed">
                                {t}
                              </div>
                            ))}
                          </div>
                        </div>

                        <div className="bg-slate-950 border border-slate-800 p-4 rounded-xl space-y-2.5">
                          <h5 className="text-[10px] font-bold text-red-400 uppercase tracking-widest border-b border-slate-800/80 pb-1.5 flex items-center gap-1.5">
                            <span className="w-1.5 h-1.5 bg-red-500 rounded-full"></span>
                            Suspended (Deferred)
                          </h5>
                          <div className="space-y-2">
                            {emergencyResponse.removedTasks.map((t, idx) => (
                              <div key={idx} className="bg-red-950/20 border border-red-900/30 p-2.5 rounded-lg text-xs font-semibold text-slate-400 line-through leading-relaxed">
                                {t}
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>

                      {/* AI identity watermark */}
                      <div className="flex items-center justify-end pt-3 border-t border-red-500/20 text-[10px] text-red-400/80 font-display font-semibold">
                        Powered by DeadlinePilot AI
                      </div>

                    </div>
                  )
                )}
              </div>
            )}
            
            {/* Top row: Section C (Productivity Widget) & Section B (AI Suggestions Panel) */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              
              {/* SECTION C: Productivity Widget */}
              <div className={`rounded-2xl shadow-xs border p-6 flex flex-col justify-between transition-all duration-500 ${
                isEmergencyModeActive
                  ? "bg-slate-900 border-red-500/20 text-white shadow-[0_0_30px_rgba(239,68,68,0.05)]"
                  : "bg-white border-slate-200"
              }`}>
                <div>
                  <div className={`flex items-center justify-between border-b pb-3 mb-4 ${
                    isEmergencyModeActive ? "border-slate-800" : "border-slate-100"
                  }`}>
                    <h3 className="text-sm font-bold flex items-center gap-2">
                      <PieChart className={`w-4 h-4 ${isEmergencyModeActive ? "text-red-500 animate-pulse" : "text-blue-600"}`} />
                      Section C: Productivity Widget
                    </h3>
                    <span className="text-[10px] text-slate-400 uppercase tracking-wider font-mono">Live telemetry</span>
                  </div>

                  <div className="flex flex-col items-center justify-center py-4 relative">
                    {/* SVG Circular Progress bar */}
                    <div className="relative w-32 h-32 flex items-center justify-center">
                      <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
                        {/* Background track */}
                        <circle 
                          cx="50" 
                          cy="50" 
                          r="40" 
                          className={isEmergencyModeActive ? "stroke-slate-850 fill-transparent" : "stroke-slate-100 fill-transparent"} 
                          strokeWidth="8"
                        />
                        {/* Interactive fill track based on computed score */}
                        <circle 
                          cx="50" 
                          cy="50" 
                          r="40" 
                          className={`${
                            isEmergencyModeActive ? "stroke-red-500" : "stroke-blue-600"
                          } fill-transparent transition-all duration-700`} 
                          strokeWidth="8"
                          strokeDasharray={251.2}
                          strokeDashoffset={251.2 - (251.2 * focusScore) / 100}
                          strokeLinecap="round"
                        />
                      </svg>
                      {/* Inner numeric indicator */}
                      <div className="absolute text-center">
                        <span className={`text-3xl font-black tracking-tight ${isEmergencyModeActive ? "text-red-500" : "text-slate-900"}`}>{focusScore}</span>
                        <span className="text-xs text-slate-400 block font-bold">PTS</span>
                      </div>
                    </div>

                    <p className="text-xs text-slate-450 font-semibold mt-4 text-center">
                      Pilot Focus Rating index
                    </p>
                  </div>
                </div>

                <div className={`border-t pt-4 mt-2 grid grid-cols-3 gap-2 text-center ${
                  isEmergencyModeActive ? "border-slate-850" : "border-slate-100"
                }`}>
                  <div>
                    <span className="text-xs text-slate-400 block font-medium">Focus Score</span>
                    <span className={`text-sm font-black ${isEmergencyModeActive ? "text-slate-100" : "text-slate-800"}`}>{focusScore}/100</span>
                  </div>
                  <div>
                    <span className="text-xs text-slate-400 block font-medium">Completion</span>
                    <span className="text-sm font-bold text-emerald-600">{completionRate}%</span>
                  </div>
                  <div>
                    <span className="text-xs text-slate-400 block font-medium">Risk Level</span>
                    <span className={`text-sm font-bold ${isEmergencyModeActive ? "text-red-500" : isAtRisk ? "text-red-600" : "text-emerald-600"}`}>
                      {isEmergencyModeActive ? "CRITICAL" : isAtRisk ? "High" : "Low"}
                    </span>
                  </div>
                </div>
              </div>

              {/* SECTION B: AI Suggestions Panel */}
              <div className="lg:col-span-2 bg-slate-900 text-white rounded-2xl shadow-lg p-6 flex flex-col justify-between relative overflow-hidden">
                {/* Visual subtle glows */}
                <div className="absolute top-0 right-0 w-36 h-36 bg-blue-500/10 rounded-full blur-3xl pointer-events-none"></div>
                <div className="absolute bottom-0 left-0 w-36 h-36 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none"></div>

                <div>
                  <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
                    <div className="flex items-center gap-2">
                      <Sparkles className="w-4.5 h-4.5 text-blue-400 animate-pulse" />
                      <h3 className="text-sm font-bold text-slate-100 uppercase tracking-wider">
                        Section B: AI Pilot Suggestions
                      </h3>
                    </div>
                    <span className="text-[10px] bg-blue-500/20 text-blue-300 font-bold px-2 py-0.5 rounded-md">
                      Smart Assistant
                    </span>
                  </div>

                  <div className="space-y-3.5">
                    {mockAISuggestions.map((sug) => (
                      <div 
                        key={sug.id} 
                        className="p-3 bg-slate-800/60 border border-slate-700/50 rounded-xl hover:bg-slate-800 transition-colors flex items-start gap-3"
                      >
                        {sug.type === "warning" ? (
                          <AlertTriangle className="w-4.5 h-4.5 text-amber-400 flex-shrink-0 mt-0.5" />
                        ) : sug.type === "tip" ? (
                          <Lightbulb className="w-4.5 h-4.5 text-blue-400 flex-shrink-0 mt-0.5" />
                        ) : (
                          <CircleDot className="w-4.5 h-4.5 text-emerald-400 flex-shrink-0 mt-0.5" />
                        )}
                        <div>
                          <p className="text-xs text-slate-200 leading-relaxed font-medium">
                            {sug.message}
                          </p>
                          <span className="text-[10px] text-blue-300/90 font-bold flex items-center gap-0.5 mt-1">
                            <ArrowUpRight className="w-3 h-3" /> Impact: {sug.impact}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <p className="text-[10px] text-slate-400 italic text-center mt-4">
                  *Suggestions calculate in real-time from active roadmap priorities below.
                </p>
              </div>

            </div>

            {/* SECTION A: Task Board & Creation Panel */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              
              {/* Task list roadmap */}
              <div className={`lg:col-span-2 rounded-2xl shadow-xs border p-6 space-y-6 transition-all duration-500 ${
                isEmergencyModeActive
                  ? "bg-slate-900 border-red-500/20 text-white shadow-[0_0_35px_rgba(239,68,68,0.05)]"
                  : "bg-white border-slate-200"
              }`}>
                
                <div className={`flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b pb-4 ${
                  isEmergencyModeActive ? "border-slate-800" : "border-slate-100"
                }`}>
                  <div>
                    <h2 className={`text-base font-bold flex items-center gap-1.5 ${
                      isEmergencyModeActive ? "text-slate-100" : "text-slate-900"
                    }`}>
                      <ListTodo className={`w-5 h-5 ${isEmergencyModeActive ? "text-red-500" : "text-blue-600"}`} />
                      Section A: Interactive Task Board
                    </h2>
                    <p className="text-xs text-slate-400">Click a task's checkbox or status badge to cycle states</p>
                  </div>

                  {/* Enhanced Status Filtering Buttons */}
                  <div className="flex flex-wrap gap-1 bg-slate-100 p-1 rounded-xl border border-slate-200 self-start">
                    {[
                      { id: "ALL", label: "All" },
                      { id: "PENDING", label: "Pending" },
                      { id: "IN_PROGRESS", label: "In Dev" },
                      { id: "COMPLETED", label: "Done" },
                      { id: "HIGH_PRIORITY", label: "High priority" },
                    ].map((f) => (
                      <button
                        key={f.id}
                        onClick={() => setFilter(f.id)}
                        className={`text-xs font-semibold px-2.5 py-1.5 rounded-lg transition-all cursor-pointer ${
                          filter === f.id 
                            ? "bg-white text-slate-900 shadow-xs border border-slate-200/20" 
                            : "text-slate-500 hover:text-slate-900"
                        }`}
                      >
                        {f.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Roadmapped tasks rendering */}
                <div className="space-y-3">
                  {filteredTasks.length === 0 ? (
                    <div className={`text-center py-12 rounded-2xl border border-dashed transition-all ${
                      isEmergencyModeActive 
                        ? "bg-slate-950/50 border-red-500/25" 
                        : "bg-slate-50 border-slate-200"
                    }`}>
                      <Layers className={`w-10 h-10 mx-auto mb-3 ${isEmergencyModeActive ? "text-red-500/50" : "text-slate-300"}`} />
                      <p className={`text-sm font-bold font-display ${isEmergencyModeActive ? "text-slate-200" : "text-slate-700"}`}>No milestones match this filter</p>
                      <p className="text-xs text-slate-400 mt-1">
                        {isEmergencyModeActive 
                          ? "Non-essential tasks are hidden during Emergency mode. Focus purely on high-priority paths!"
                          : "Try toggling other statuses or define a new milestone task."}
                      </p>
                    </div>
                  ) : (
                    filteredTasks.map((task) => (
                      <div 
                        key={task.id}
                        className={`flex flex-col sm:flex-row sm:items-center justify-between p-4 rounded-xl border transition-all ${
                          task.status === "Done" 
                            ? isEmergencyModeActive 
                              ? "bg-slate-900/30 border-slate-800 opacity-50 hover:opacity-85 text-slate-300"
                              : "bg-slate-50/40 border-slate-150 opacity-70 hover:opacity-90 text-slate-500" 
                            : task.status === "Missed"
                              ? isEmergencyModeActive
                                ? "bg-red-950/40 border-red-900/60 hover:border-red-500 text-red-100"
                                : "bg-red-50/20 border-red-200/60 hover:border-red-300"
                              : task.status === "Delayed"
                                ? isEmergencyModeActive
                                  ? "bg-amber-950/40 border-amber-900/60 hover:border-amber-500 text-amber-100"
                                  : "bg-amber-50/20 border-amber-200/60 hover:border-amber-300"
                                : task.priority === "High"
                                  ? isEmergencyModeActive
                                    ? "bg-red-950/30 border-red-900/50 hover:border-red-500 text-red-50"
                                    : "bg-red-50/10 border-red-200/50 hover:border-red-300"
                                  : isEmergencyModeActive
                                    ? "bg-slate-900 border-slate-800 hover:border-slate-700 text-white"
                                    : "bg-white border-slate-200 hover:border-slate-300 shadow-xs"
                        }`}
                      >
                        <div className="flex items-start gap-3.5">
                          {/* Toggle Task completion directly */}
                          <button
                            onClick={() => cycleTaskStatus(task.id)}
                            className="mt-0.5 text-slate-400 hover:text-blue-600 transition-colors cursor-pointer flex-shrink-0"
                            title="Cycle Task Status"
                          >
                            {task.status === "Done" ? (
                              <CheckCircle2 className="w-5 h-5 text-emerald-500 fill-emerald-50" />
                            ) : task.status === "In Progress" ? (
                              <div className="w-5 h-5 rounded-full border-2 border-blue-500 flex items-center justify-center">
                                <div className="w-2.5 h-2.5 bg-blue-500 rounded-full animate-ping"></div>
                              </div>
                            ) : task.status === "Delayed" ? (
                              <AlertTriangle className="w-5 h-5 text-amber-500" />
                            ) : task.status === "Missed" ? (
                              <AlertTriangle className="w-5 h-5 text-red-500" />
                            ) : (
                              <div className="w-5 h-5 rounded-full border-2 border-slate-300 hover:border-blue-500"></div>
                            )}
                          </button>
                          
                          <div>
                            <p className={`text-sm font-bold tracking-tight ${task.status === "Done" ? "line-through text-slate-400" : isEmergencyModeActive ? "text-slate-100" : "text-slate-900"}`}>
                              {task.title}
                            </p>
                            
                            <div className="flex flex-wrap items-center gap-2 mt-2">
                              {/* Category pill */}
                              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 bg-slate-100 px-2 py-0.5 rounded-md border border-slate-200">
                                {task.category}
                              </span>
                              
                              {/* Status Badge - Clicking cycles state */}
                              <button 
                                onClick={() => cycleTaskStatus(task.id)}
                                className={`text-[10px] font-extrabold uppercase tracking-wider px-2 py-0.5 rounded-md border cursor-pointer ${
                                  task.status === "Done"
                                    ? "bg-emerald-50 text-emerald-700 border-emerald-200"
                                    : task.status === "In Progress"
                                      ? "bg-blue-50 text-blue-700 border-blue-200"
                                      : task.status === "Delayed"
                                        ? "bg-amber-50 text-amber-700 border-amber-200"
                                        : task.status === "Missed"
                                          ? "bg-red-50 text-red-700 border-red-200"
                                          : "bg-slate-100 text-slate-600 border-slate-200"
                                }`}
                              >
                                {task.status}
                              </button>

                              {/* Priority Badge */}
                              <span className={`text-[10px] font-extrabold uppercase tracking-wider px-2 py-0.5 rounded-md border ${
                                task.priority === "High" 
                                  ? "bg-red-50 text-red-700 border-red-200/50" 
                                  : task.priority === "Medium"
                                    ? "bg-amber-50 text-amber-700 border-amber-200/50"
                                    : "bg-slate-100 text-slate-600 border-slate-200"
                              }`}>
                                {task.priority}
                              </span>

                              {/* Assignee label */}
                              <span className="text-xs text-slate-400 flex items-center gap-1 font-medium">
                                <User className="w-3.5 h-3.5 text-slate-400" /> {task.assignee}
                              </span>
                            </div>
                          </div>
                        </div>

                        {/* Right side task actions */}
                        <div className="flex items-center justify-between sm:justify-end gap-4 mt-4 sm:mt-0 pt-3 sm:pt-0 border-t sm:border-t-0 border-slate-100">
                          <span className="text-xs text-slate-400 flex items-center gap-1 font-mono font-bold bg-slate-50 px-2 py-1 rounded-md border border-slate-100">
                            <Clock className="w-3.5 h-3.5 text-slate-400" />
                            {task.deadline}
                          </span>
                          
                          <button 
                            onClick={() => deleteTask(task.id)}
                            className="p-1.5 text-slate-400 hover:text-red-500 rounded-lg hover:bg-slate-50 transition-colors cursor-pointer"
                            title="Delete Milestone"
                          >
                            <Trash2 className="w-4.5 h-4.5" />
                          </button>
                        </div>
                      </div>
                    ))
                  )}
                </div>

              </div>

              {/* Task Creation Form Side Card & AI Task Breakdown Co-pilot */}
              <div className="space-y-6 lg:col-span-1">
                <div className={`rounded-2xl shadow-xs border p-6 h-fit space-y-4 transition-all duration-500 ${
                  isEmergencyModeActive
                    ? "bg-slate-900 border-red-500/20 text-white shadow-[0_0_35px_rgba(239,68,68,0.05)]"
                    : "bg-white border-slate-200"
                }`}>
                  <h3 className={`text-md font-bold flex items-center gap-1.5 ${
                    isEmergencyModeActive ? "text-slate-100" : "text-slate-900"
                  }`}>
                    <Plus className={`w-4.5 h-4.5 ${isEmergencyModeActive ? "text-red-500" : "text-blue-600"}`} />
                    Create Sandbox Task
                  </h3>
                  <p className="text-xs text-slate-400">Append high-priority sprints to target on-time delivery</p>

                  <form onSubmit={handleAddTask} className="space-y-4">
                    <div>
                      <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">Task Title</label>
                      <input
                        type="text"
                        required
                        value={newTaskTitle}
                        onChange={(e) => setNewTaskTitle(e.target.value)}
                        placeholder="e.g. Implement real-time websocket checks"
                        className={`w-full text-xs border rounded-lg px-3 py-2.5 focus:outline-none focus:ring-1 transition-all ${
                          isEmergencyModeActive 
                            ? "bg-slate-950 border-slate-800 text-white focus:ring-red-500 focus:border-red-500" 
                            : "bg-slate-50/50 border-slate-200 text-slate-900 focus:ring-blue-500 focus:border-blue-500"
                        }`}
                      />
                      {newTaskTitle.trim().length > 3 && (
                        <button
                          type="button"
                          onClick={() => handleAIBreakdown(newTaskTitle)}
                          className={`w-full mt-2 rounded-lg py-2 text-[11px] font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer border ${
                            isEmergencyModeActive
                              ? "bg-red-950/40 hover:bg-red-950/60 text-red-400 border-red-900/30"
                              : "bg-gradient-to-r from-blue-50 to-indigo-50 hover:from-blue-100 hover:to-indigo-100 text-blue-700 border-blue-200/50"
                          }`}
                        >
                          <Sparkles className={`w-3.5 h-3.5 animate-pulse ${isEmergencyModeActive ? "text-red-500" : "text-blue-600"}`} />
                          Break this task using AI
                        </button>
                      )}
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">Category</label>
                        <select
                          value={newTaskCategory}
                          onChange={(e) => setNewTaskCategory(e.target.value as any)}
                          className={`w-full text-xs border rounded-lg px-2 py-2.5 focus:outline-none transition-all ${
                            isEmergencyModeActive 
                              ? "bg-slate-950 border-slate-800 text-white focus:ring-red-500 focus:border-red-500" 
                              : "bg-white border-slate-200 text-slate-900"
                          }`}
                        >
                          <option value="Frontend">Frontend</option>
                          <option value="Backend">Backend</option>
                          <option value="Design">Design</option>
                          <option value="Pitch">Pitch Deck</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">Priority</label>
                        <select
                          value={newTaskPriority}
                          onChange={(e) => setNewTaskPriority(e.target.value as any)}
                          className={`w-full text-xs border rounded-lg px-2 py-2.5 focus:outline-none transition-all ${
                            isEmergencyModeActive 
                              ? "bg-slate-950 border-slate-800 text-white focus:ring-red-500 focus:border-red-500" 
                              : "bg-white border-slate-200 text-slate-900"
                          }`}
                        >
                          <option value="High">High</option>
                          <option value="Medium">Medium</option>
                          <option value="Low">Low</option>
                        </select>
                      </div>
                    </div>

                    <div>
                      <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">Assignee</label>
                      <input
                        type="text"
                        value={newTaskAssignee}
                        onChange={(e) => setNewTaskAssignee(e.target.value)}
                        placeholder="e.g. Alex"
                        className={`w-full text-xs border rounded-lg px-3 py-2.5 focus:outline-none focus:ring-1 transition-all ${
                          isEmergencyModeActive 
                            ? "bg-slate-950 border-slate-800 text-white focus:ring-red-500 focus:border-red-500" 
                            : "bg-slate-50/50 border-slate-200 text-slate-900 focus:ring-blue-500 focus:border-blue-500"
                        }`}
                      />
                    </div>

                    <div>
                      <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">Time Deadline</label>
                      <input
                        type="text"
                        value={newTaskDeadline}
                        onChange={(e) => setNewTaskDeadline(e.target.value)}
                        placeholder="e.g. 4 hours left"
                        className={`w-full text-xs border rounded-lg px-3 py-2.5 focus:outline-none focus:ring-1 transition-all ${
                          isEmergencyModeActive 
                            ? "bg-slate-950 border-slate-800 text-white focus:ring-red-500 focus:border-red-500" 
                            : "bg-slate-50/50 border-slate-200 text-slate-900 focus:ring-blue-500 focus:border-blue-500"
                        }`}
                      />
                    </div>

                    <button
                      type="submit"
                      className={`w-full rounded-lg py-3 text-xs font-semibold shadow-xs transition-colors flex items-center justify-center gap-1.5 cursor-pointer text-white ${
                        isEmergencyModeActive
                          ? "bg-red-600 hover:bg-red-700 shadow-[0_0_15px_rgba(239,68,68,0.3)]"
                          : "bg-blue-600 hover:bg-blue-700"
                      }`}
                    >
                      <Plus className="w-4 h-4" /> Add Task
                    </button>
                  </form>
                </div>

                {/* AI Task Breakdown Co-pilot Card */}
                <div className="bg-white rounded-2xl shadow-xs border border-slate-200 p-6 space-y-5">
                  <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                    <div className="flex items-center gap-1.5">
                      <Sparkles className="w-5 h-5 text-blue-600 animate-pulse" />
                      <h3 className="text-sm font-bold text-slate-900 tracking-tight">AI Task Breakdown</h3>
                    </div>
                    <span className="text-[10px] bg-blue-100 text-blue-800 font-extrabold px-2 py-0.5 rounded-full uppercase tracking-wider">
                      Co-pilot
                    </span>
                  </div>

                  <p className="text-xs text-slate-500 leading-relaxed">
                    Instantly split high-level objectives into micro-milestones to secure on-time delivery.
                  </p>

                  {/* Predefined Quick Suggestion Tags */}
                  <div className="space-y-2">
                    <span className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider">Quick Templates</span>
                    <div className="flex flex-wrap gap-1.5">
                      {[
                        { label: "DSA Sheet", task: "Complete DSA Sheet" },
                        { label: "Backend Auth", task: "Build Backend Auth" },
                        { label: "Presentation", task: "Record Project Presentation" },
                        { label: "Dashboard Theme", task: "Design Tailwind Dashboard Theme" }
                      ].map((item, idx) => (
                        <button
                          key={idx}
                          type="button"
                          onClick={() => {
                            setBreakdownInput(item.task);
                            handleAIBreakdown(item.task);
                          }}
                          className="text-[11px] font-semibold bg-slate-50 hover:bg-slate-100 text-slate-700 hover:text-slate-950 px-2.5 py-1 rounded-lg border border-slate-200/60 transition-all cursor-pointer"
                        >
                          + {item.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Custom input box */}
                  <div className="space-y-2 pt-2 border-t border-slate-100">
                    <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider">Enter big task</label>
                    <div className="flex gap-2">
                      <input
                        type="text"
                        value={breakdownInput}
                        onChange={(e) => setBreakdownInput(e.target.value)}
                        placeholder="e.g. Complete DSA Sheet"
                        className="flex-grow text-xs border border-slate-200 rounded-lg px-3 py-2 focus:outline-none focus:ring-1 focus:ring-blue-500 bg-slate-50/50"
                      />
                      <button
                        type="button"
                        disabled={isBreakingDown || !breakdownInput.trim()}
                        onClick={() => handleAIBreakdown()}
                        className="bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold px-3 py-2 rounded-lg transition-colors flex items-center justify-center disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
                      >
                        {isBreakingDown ? (
                          <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                        ) : (
                          "Breakdown"
                        )}
                      </button>
                    </div>
                  </div>

                  {/* LOADING STATE */}
                  {isBreakingDown && (
                    <div className="py-8 text-center bg-blue-50/20 rounded-xl border border-dashed border-blue-200/40 space-y-2 animate-pulse">
                      <Sparkles className="w-7 h-7 text-blue-500 mx-auto animate-spin" />
                      <p className="text-xs font-semibold text-slate-700">Consulting Gemini Advisor API...</p>
                      <p className="text-[10px] text-slate-400">Structuring chronological milestone pathing</p>
                    </div>
                  )}

                  {/* COMPLETED RESULT VIEW */}
                  {breakdownResult && (
                    <div className="bg-slate-50 border border-slate-150 rounded-xl p-4 space-y-4 animate-fadeIn">
                      <div>
                        <div className="flex items-center justify-between gap-4 mb-1">
                          <span className="text-[10px] text-blue-600 font-extrabold uppercase tracking-wider block">
                            Analyzing Objective
                          </span>
                          <span className="text-[9px] text-slate-400 font-bold font-display">Powered by DeadlinePilot AI</span>
                        </div>
                        <h4 className="text-sm font-bold text-slate-900 leading-tight">
                          {breakdownResult.task}
                        </h4>
                        <div className="mt-2 flex items-center gap-1.5 text-xs text-slate-500 font-mono">
                          <Clock className="w-3.5 h-3.5 text-slate-400" />
                          <span>Estimated Time:</span>
                          <span className="font-bold text-blue-600 bg-blue-50 border border-blue-100 px-1.5 py-0.5 rounded">
                            {breakdownResult.estimatedDays} Days
                          </span>
                        </div>
                      </div>

                      {/* Breakdown list checks */}
                      <div className="space-y-2">
                        <span className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                          Chronological Sub-Milestones
                        </span>
                        <div className="space-y-1.5 max-h-[220px] overflow-y-auto pr-0.5">
                          {breakdownResult.breakdown.map((item, index) => {
                            const isChecked = !!breakdownCompletedItems[item];
                            return (
                              <div
                                key={index}
                                onClick={() => toggleBreakdownItem(item)}
                                className={`flex items-start gap-2.5 p-2 rounded-lg border transition-all cursor-pointer ${
                                  isChecked
                                    ? "bg-emerald-50/30 border-emerald-100 opacity-60"
                                    : "bg-white border-slate-100 hover:border-slate-200"
                                }`}
                              >
                                <button
                                  type="button"
                                  className={`mt-0.5 w-4 h-4 rounded flex items-center justify-center flex-shrink-0 border ${
                                    isChecked
                                      ? "bg-emerald-500 border-emerald-500 text-white"
                                      : "border-slate-300 bg-white"
                                  }`}
                                >
                                  {isChecked && <span className="text-[10px] font-bold">✓</span>}
                                </button>
                                <span className={`text-xs leading-relaxed font-medium ${
                                  isChecked ? "line-through text-slate-400" : "text-slate-700"
                                }`}>
                                  {item}
                                </span>
                              </div>
                            );
                          })}
                        </div>
                      </div>

                      {/* AI advice prioritization plan */}
                      <div className="bg-amber-50/50 border border-amber-100/50 rounded-lg p-3 space-y-1">
                        <div className="flex items-center gap-1.5 text-[11px] font-bold text-amber-800">
                          <Lightbulb className="w-3.5 h-3.5 text-amber-600" />
                          AI Priority Blueprint
                        </div>
                        <p className="text-[11px] text-amber-700 leading-relaxed font-medium">
                          {breakdownResult.priorityPlan}
                        </p>
                      </div>

                      {/* Button to Inject All tasks into the main Task Board */}
                      <button
                        type="button"
                        onClick={handleInjectBreakdown}
                        className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2.5 rounded-lg text-xs transition-all flex items-center justify-center gap-1.5 shadow-xs cursor-pointer"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        Inject {breakdownResult.breakdown.length} Tasks to Active Board
                      </button>
                    </div>
                  )}
                </div>
              </div>

            </div>
 
          </motion.div>
        )}
 
        {/* Tab 2: Visual Sprint Planner */}
        {activeTab === "planner" && (
          <motion.div 
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.35, ease: "easeOut" }}
            className="space-y-6"
          >
            <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-[0_2px_12px_rgba(0,0,0,0.02)] transition-all hover:shadow-[0_4px_20px_rgba(0,0,0,0.04)]">
              <h2 className="text-base font-black font-display text-slate-900 mb-1 flex items-center gap-1.5">
                <CalendarDays className="w-5 h-5 text-blue-600" /> Hackathon Stage Planner
              </h2>
              <p className="text-xs text-slate-400 mb-6 font-medium">Track your team progression against the critical 48-hour timeline</p>

              <div className="space-y-4">
                {phases.map((phase) => (
                  <div key={phase.id} className="relative pl-6 sm:pl-8 border-l-2 border-slate-200 pb-4 last:border-l-0 last:pb-0">
                    <div className={`absolute -left-[9px] top-1.5 w-4 h-4 rounded-full border-2 flex items-center justify-center ${
                      phase.status === "Completed" 
                        ? "bg-emerald-500 border-emerald-500 text-white" 
                        : phase.status === "Active"
                          ? "bg-white border-blue-600 animate-pulse"
                          : "bg-white border-slate-300"
                    }`}>
                      {phase.status === "Completed" && <CheckSquare className="w-2.5 h-2.5" />}
                    </div>

                    <div className="bg-slate-50 p-4 rounded-xl border border-slate-100/80">
                      <div className="flex items-center justify-between flex-wrap gap-2 mb-2">
                        <h3 className="text-xs font-bold text-slate-900">{phase.title}</h3>
                        <span className={`text-[9px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full ${
                          phase.status === "Completed" 
                            ? "bg-emerald-100 text-emerald-800" 
                            : phase.status === "Active"
                              ? "bg-blue-100 text-blue-800"
                              : "bg-slate-200 text-slate-600"
                        }`}>
                          {phase.status}
                        </span>
                      </div>

                      <ul className="grid grid-cols-1 md:grid-cols-3 gap-2.5">
                        {phase.items.map((item, i) => (
                          <li key={i} className="flex items-center gap-2 text-xs text-slate-600">
                            <span className="w-1.5 h-1.5 bg-slate-400 rounded-full flex-shrink-0"></span>
                            <span>{item}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* AI DAILY PLANNER SECTION */}
            <div className="bg-white p-6 rounded-2xl border border-slate-200 space-y-6">
              <div className="flex items-center justify-between flex-wrap gap-4 border-b border-slate-100 pb-4">
                <div>
                  <h2 className="text-base font-bold text-slate-900 flex items-center gap-1.5">
                    <Sparkles className="w-5 h-5 text-blue-600 animate-pulse" />
                    Today's AI Schedule
                  </h2>
                  <p className="text-xs text-slate-400">Synthesize customized hourly priorities based on active tasks and your available hours</p>
                </div>
                
                <div className="flex items-center gap-3">
                  <div className="flex items-center gap-2">
                    <label className="text-xs font-semibold text-slate-500 whitespace-nowrap">Working Hours:</label>
                    <input
                      type="number"
                      min="1"
                      max="24"
                      value={availableHours}
                      onChange={(e) => setAvailableHours(Math.max(1, Math.min(24, Number(e.target.value) || 8)))}
                      className="w-16 text-center text-xs font-bold border border-slate-200 rounded-lg py-1.5 bg-slate-50 focus:outline-none"
                    />
                  </div>

                  <button
                    onClick={handleGenerateDailyPlan}
                    disabled={isPlanning}
                    className="bg-blue-600 hover:bg-blue-700 text-white font-semibold px-4 py-2 rounded-xl text-xs flex items-center gap-2 transition-all cursor-pointer shadow-xs disabled:opacity-50"
                  >
                    {isPlanning ? (
                      <>
                        <div className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                        Generating Plan...
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-4 h-4" />
                        Generate My Day Plan
                      </>
                    )}
                  </button>
                </div>
              </div>

              {/* Loader */}
              {isPlanning && (
                <div className="py-12 text-center bg-blue-50/10 rounded-2xl border border-dashed border-blue-200/40 space-y-3 animate-pulse">
                  <Sparkles className="w-8 h-8 text-blue-500 mx-auto animate-spin" />
                  <p className="text-sm font-semibold text-slate-700">Analyzing roadmap backlog & team velocities...</p>
                  <p className="text-xs text-slate-400">Allocating focus hours based on item priority metrics</p>
                </div>
              )}

              {/* Day Plan Display */}
              {dailyPlanResult ? (
                <div className="space-y-6 animate-fadeIn">
                  
                  {/* Top reasoning & score row */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="md:col-span-2 bg-slate-50 border border-slate-100 p-4 rounded-xl flex items-start gap-3">
                      <Lightbulb className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                      <div className="flex-grow">
                        <div className="flex items-center justify-between gap-4 mb-0.5">
                          <span className="text-[10px] text-blue-600 font-extrabold uppercase tracking-wider block">
                            AI Scheduler Reasoning
                          </span>
                          <span className="text-[9px] text-slate-400 font-bold font-display">Powered by DeadlinePilot AI</span>
                        </div>
                        <p className="text-xs text-slate-600 leading-relaxed font-medium">
                          {dailyPlanResult.reasoning}
                        </p>
                      </div>
                    </div>

                    <div className="bg-slate-900 text-white p-4 rounded-xl flex flex-col justify-between relative overflow-hidden">
                      <div className="absolute top-0 right-0 w-24 h-24 bg-blue-500/10 rounded-full blur-2xl"></div>
                      <div>
                        <span className="text-[10px] text-slate-400 font-extrabold uppercase tracking-wider block">
                          Productivity Index
                        </span>
                        <span className="text-2xl font-black text-slate-100 mt-1 block">
                          {dailyPlanResult.estimatedProductivityScore}%
                        </span>
                      </div>
                      <span className="text-[10px] text-emerald-400 font-semibold mt-2">
                        Optimal allocation detected
                      </span>
                    </div>
                  </div>

                  {/* Morning / Afternoon / Evening Cards */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    {/* Morning Card */}
                    <div className="border border-slate-150 rounded-xl p-4 bg-white shadow-xs space-y-3">
                      <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                        <span className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                          <span className="w-2.5 h-2.5 bg-amber-400 rounded-full"></span>
                          Morning Focus
                        </span>
                        <span className="text-[10px] font-mono text-slate-400 font-bold">09:00 - 12:00</span>
                      </div>
                      <div className="space-y-2">
                        {dailyPlanResult.schedule.morning.map((act, i) => (
                          <div key={i} className="bg-slate-50 p-2.5 rounded-lg border border-slate-100 text-xs text-slate-700 font-medium">
                            {act}
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Afternoon Card */}
                    <div className="border border-slate-150 rounded-xl p-4 bg-white shadow-xs space-y-3">
                      <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                        <span className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                          <span className="w-2.5 h-2.5 bg-blue-500 rounded-full animate-pulse"></span>
                          Afternoon Sprint
                        </span>
                        <span className="text-[10px] font-mono text-slate-400 font-bold">13:00 - 17:00</span>
                      </div>
                      <div className="space-y-2">
                        {dailyPlanResult.schedule.afternoon.map((act, i) => (
                          <div key={i} className="bg-slate-50 p-2.5 rounded-lg border border-slate-100 text-xs text-slate-700 font-medium">
                            {act}
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Evening Card */}
                    <div className="border border-slate-150 rounded-xl p-4 bg-white shadow-xs space-y-3">
                      <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                        <span className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                          <span className="w-2.5 h-2.5 bg-indigo-950 rounded-full"></span>
                          Evening Wrap-up
                        </span>
                        <span className="text-[10px] font-mono text-slate-400 font-bold">18:00 - 21:00</span>
                      </div>
                      <div className="space-y-2">
                        {dailyPlanResult.schedule.evening.map((act, i) => (
                          <div key={i} className="bg-slate-50 p-2.5 rounded-lg border border-slate-100 text-xs text-slate-700 font-medium">
                            {act}
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>

                </div>
              ) : (
                !isPlanning && (
                  <div className="text-center py-8 bg-slate-50/50 rounded-2xl border border-dashed border-slate-200/60 flex flex-col items-center justify-center">
                    <Calendar className="w-8 h-8 text-slate-300 mb-2" />
                    <p className="text-xs font-semibold text-slate-600">No active daily plan generated for today</p>
                    <p className="text-[11px] text-slate-400 mt-1">Click "Generate My Day Plan" to structure your workspace priorities based on your available hours.</p>
                  </div>
                )
              )}
            </div>

            {/* SMART REPLANNING ENGINE PANEL */}
            <div className="bg-white p-6 rounded-2xl border border-slate-200 space-y-6">
              <div className="flex items-center justify-between flex-wrap gap-4 border-b border-slate-100 pb-4">
                <div>
                  <h2 className="text-base font-bold text-slate-900 flex items-center gap-1.5">
                    <ShieldAlert className="w-5 h-5 text-amber-500" />
                    Adaptive Smart Replanning Engine
                  </h2>
                  <p className="text-xs text-slate-400">
                    AI-powered adaptive scheduler. Recomputes timelines automatically when delays or missed states occur.
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleSmartReplan(tasks, true)}
                    disabled={isReplanning}
                    className="bg-amber-500 hover:bg-amber-600 text-slate-950 font-semibold px-4 py-2 rounded-xl text-xs flex items-center gap-1.5 transition-all cursor-pointer shadow-xs disabled:opacity-50 font-sans"
                  >
                    {isReplanning ? (
                      <>
                        <div className="w-3.5 h-3.5 border-2 border-slate-950/30 border-t-slate-950 rounded-full animate-spin"></div>
                        Recomputing...
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-4 h-4" />
                        Replan My Day
                      </>
                    )}
                  </button>
                </div>
              </div>

              {/* Loader */}
              {isReplanning && (
                <div className="py-12 text-center bg-amber-50/10 rounded-2xl border border-dashed border-amber-200/40 space-y-3 animate-pulse">
                  <Sparkles className="w-8 h-8 text-amber-500 mx-auto animate-spin" />
                  <p className="text-sm font-semibold text-slate-700">Recalculating pending milestones & timelines...</p>
                  <p className="text-xs text-slate-400">Shifting non-critical tasks to establish timeline safety</p>
                </div>
              )}

              {/* Plan Display */}
              {replanResult ? (
                <div className="space-y-6 animate-fadeIn">
                  
                  {/* Status row: Risk level, trigger condition, estimated safety */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="bg-slate-50 border border-slate-150 p-4 rounded-xl flex items-start gap-3">
                      <AlertTriangle className="w-5 h-5 text-amber-500 mt-0.5" />
                      <div>
                        <span className="text-[10px] text-amber-700 font-extrabold uppercase tracking-wider block">
                          Scheduler Trigger
                        </span>
                        <p className="text-xs text-slate-700 font-semibold mt-1">
                          {lastReplanTrigger || "Automated state change detection"}
                        </p>
                      </div>
                    </div>

                    <div className={`p-4 rounded-xl border flex flex-col justify-between ${
                      replanResult.riskLevel === "High"
                        ? "bg-red-50/40 border-red-100 text-red-900"
                        : replanResult.riskLevel === "Medium"
                          ? "bg-amber-50/40 border-amber-100 text-amber-900"
                          : "bg-emerald-50/40 border-emerald-100 text-emerald-900"
                    }`}>
                      <div>
                        <span className="text-[10px] font-extrabold uppercase tracking-wider block opacity-70">
                          Timeline Risk level
                        </span>
                        <span className="text-sm font-black mt-1 block flex items-center gap-1.5">
                          {replanResult.riskLevel === "High" && "⚠️ "}
                          {replanResult.riskLevel}
                        </span>
                      </div>
                      <span className="text-[10px] font-semibold mt-2 block opacity-85">
                        {replanResult.riskLevel === "High" 
                          ? "Critical path is overloaded" 
                          : "Adequate milestone buffers established"}
                      </span>
                    </div>

                    <div className="bg-slate-900 text-white p-4 rounded-xl flex flex-col justify-between relative overflow-hidden">
                      <div className="absolute top-0 right-0 w-24 h-24 bg-amber-500/10 rounded-full blur-2xl"></div>
                      <div>
                        <span className="text-[10px] text-slate-400 font-extrabold uppercase tracking-wider block">
                          Task Adaptation Index
                        </span>
                        <span className="text-xl font-black text-amber-400 mt-1 block">
                          Optimized
                        </span>
                      </div>
                      <span className="text-[10px] text-emerald-400 font-semibold mt-2">
                        Resource layout optimized
                      </span>
                    </div>
                  </div>

                  {/* AI Explanation reasoning */}
                  <div className="bg-blue-50/20 border border-blue-100 p-4 rounded-xl flex items-start gap-3">
                    <Lightbulb className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                    <div className="flex-grow">
                      <div className="flex items-center justify-between gap-4 mb-0.5">
                        <span className="text-[10px] text-blue-700 font-extrabold uppercase tracking-wider block">
                          AI Adaptive Reasoning
                        </span>
                        <span className="text-[9px] text-slate-400 font-bold font-display">Powered by DeadlinePilot AI</span>
                      </div>
                      <p className="text-xs text-slate-700 leading-relaxed font-medium">
                        {replanResult.reasoning}
                      </p>
                    </div>
                  </div>

                  {/* Highlighting changes panel */}
                  <div className="bg-amber-50/30 border border-amber-200/50 p-4 rounded-xl space-y-2.5">
                    <h4 className="text-xs font-bold text-amber-950 flex items-center gap-1.5">
                      <Sparkles className="w-4 h-4 text-amber-600" />
                      Dynamic Timeline Modifications
                    </h4>
                    <div className="space-y-1.5">
                      {replanResult.changes.map((change, idx) => (
                        <div key={idx} className="flex items-start gap-2 text-xs text-slate-700">
                          <span className="text-amber-500 mt-0.5 font-bold">•</span>
                          <p className="leading-relaxed font-medium">{change}</p>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Before vs After comparison layout */}
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 pt-2">
                    {/* Before Schedule Column */}
                    <div className="border border-slate-150 rounded-xl p-4 bg-slate-50/50 space-y-3 opacity-75">
                      <h4 className="text-xs font-bold text-slate-500 border-b border-slate-100 pb-2 flex items-center justify-between">
                        <span>Original Daily Schedule</span>
                        <span className="text-[9px] font-mono font-bold uppercase tracking-wider bg-slate-100 px-1.5 py-0.5 rounded text-slate-400">Stale</span>
                      </h4>
                      <div className="space-y-3">
                        <div>
                          <span className="text-[10px] font-bold text-slate-400 block mb-1">Morning Focus</span>
                          <div className="bg-white p-2.5 rounded-lg border border-slate-100 text-xs text-slate-500 line-through">
                            Focus Hour: Configure Firebase security rules and initialize schemas
                          </div>
                        </div>
                        <div>
                          <span className="text-[10px] font-bold text-slate-400 block mb-1">Afternoon Sprint</span>
                          <div className="bg-white p-2.5 rounded-lg border border-slate-100 text-xs text-slate-500 line-through">
                            Development Session: Deploy express proxy to Google Cloud Run
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* After Schedule Column */}
                    <div className="border border-amber-200 rounded-xl p-4 bg-amber-50/10 space-y-3 shadow-xs">
                      <h4 className="text-xs font-bold text-amber-900 border-b border-amber-100 pb-2 flex items-center justify-between">
                        <span>AI Adaptive Replan</span>
                        <span className="text-[9px] font-mono font-bold uppercase tracking-wider bg-amber-100 text-amber-800 px-1.5 py-0.5 rounded">Active</span>
                      </h4>
                      <div className="space-y-4">
                        <div>
                          <span className="text-[10px] font-extrabold text-amber-800 block mb-1.5">Morning Session</span>
                          <div className="space-y-1.5">
                            {replanResult.updatedSchedule.morning.map((act, i) => (
                              <div key={i} className="bg-white p-2.5 rounded-lg border border-amber-100/60 text-xs text-amber-950 font-semibold shadow-2xs">
                                {act}
                              </div>
                            ))}
                          </div>
                        </div>
                        <div>
                          <span className="text-[10px] font-extrabold text-amber-800 block mb-1.5">Afternoon Session</span>
                          <div className="space-y-1.5">
                            {replanResult.updatedSchedule.afternoon.map((act, i) => (
                              <div key={i} className="bg-white p-2.5 rounded-lg border border-amber-100/60 text-xs text-amber-950 font-semibold shadow-2xs">
                                {act}
                              </div>
                            ))}
                          </div>
                        </div>
                        <div>
                          <span className="text-[10px] font-extrabold text-amber-800 block mb-1.5">Evening Session</span>
                          <div className="space-y-1.5">
                            {replanResult.updatedSchedule.evening.map((act, i) => (
                              <div key={i} className="bg-white p-2.5 rounded-lg border border-amber-100/60 text-xs text-amber-950 font-semibold shadow-2xs">
                                {act}
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                </div>
              ) : (
                !isReplanning && (
                  <div className="text-center py-8 bg-slate-50/50 rounded-2xl border border-dashed border-slate-200/60 flex flex-col items-center justify-center">
                    <ShieldAlert className="w-8 h-8 text-slate-300 mb-2" />
                    <p className="text-xs font-semibold text-slate-600">Smart Replanning Engine idle</p>
                    <p className="text-[11px] text-slate-400 mt-1">
                      No delay or missed task detected. If you want to force check, click "Replan My Day" or cycle a task to "Delayed"/"Missed".
                    </p>
                  </div>
                )
              )}
            </div>

            <div className="bg-blue-50/50 p-5 rounded-2xl border border-blue-100/50 flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="flex items-start gap-3">
                <Lightbulb className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                <div>
                  <h3 className="text-xs font-bold text-slate-900">Pro-Tip for Submission Success:</h3>
                  <p className="text-xs text-slate-600 mt-1">
                    Always aim to freeze features exactly 8 hours before the deadline. Spend the last 8 hours on video recording, checking deployment hosting logs, and polishing copy.
                  </p>
                </div>
              </div>
            </div>
          </motion.div>
        )}

        {/* Tab 3: AI Copilot Coach */}
        {activeTab === "coach" && (
          <motion.div 
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.35, ease: "easeOut" }}
            className="grid grid-cols-1 lg:grid-cols-3 gap-6"
          >
            
            {/* Chat Column */}
            <div className="lg:col-span-2 bg-white rounded-2xl border border-slate-200 p-5 flex flex-col justify-between min-h-[450px]">
              <div>
                <div className="flex items-center justify-between gap-4 mb-2 border-b border-slate-100 pb-3">
                  <div>
                    <h2 className="text-base font-black font-display text-slate-900 flex items-center gap-1.5">
                      <BrainCircuit className="w-5 h-5 text-blue-600" /> Pilot Companion Coach
                    </h2>
                    <p className="text-xs text-slate-400 mt-0.5 font-medium">Generates automated sprint recommendations based on task telemetry</p>
                  </div>
                  <span className="text-[9px] text-slate-400 font-bold font-display bg-slate-50 border border-slate-200/50 px-2.5 py-1 rounded-full uppercase tracking-wide">
                    Powered by DeadlinePilot AI
                  </span>
                </div>
                
                <div className="space-y-4 mt-4 max-h-[300px] overflow-y-auto pr-1">
                  {chatMessages.map((msg, i) => (
                    <div 
                      key={i} 
                      className={`flex gap-3 max-w-[85%] ${msg.sender === "user" ? "ml-auto flex-row-reverse" : ""}`}
                    >
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                        msg.sender === "user" ? "bg-slate-200 text-slate-700" : "bg-blue-600 text-white"
                      }`}>
                        {msg.sender === "user" ? <User className="w-4 h-4" /> : <Sparkles className="w-4 h-4" />}
                      </div>

                      <div className={`p-3 rounded-2xl text-xs leading-relaxed ${
                        msg.sender === "user" 
                          ? "bg-slate-100 text-slate-800 rounded-tr-none" 
                          : "bg-slate-900 text-slate-100 rounded-tl-none border border-slate-800"
                      }`}>
                        {msg.text}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Chat Send Form */}
              <form onSubmit={handleSendChatMessage} className="mt-4 flex gap-2 pt-3 border-t border-slate-100">
                <input
                  type="text"
                  value={chatInput}
                  onChange={(e) => setChatInput(e.target.value)}
                  placeholder="Ask for feedback on scope, estimates or slides..."
                  className="flex-grow text-xs border border-slate-200 rounded-xl px-3.5 py-2.5 focus:outline-none focus:ring-1 focus:ring-blue-500 bg-slate-50/50"
                />
                <button
                  type="submit"
                  className="bg-blue-600 hover:bg-blue-700 text-white p-2.5 rounded-xl transition-colors cursor-pointer"
                >
                  <Send className="w-4 h-4" />
                </button>
              </form>
            </div>

            {/* Quick Prompts Panel */}
            <div className="bg-white rounded-2xl border border-slate-200 p-5 h-fit space-y-4">
              <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">Quick Pilot Triggers</h3>
              <p className="text-[11px] text-slate-400">Tap below to auto-simulate pilot evaluation scenarios</p>

              <div className="space-y-2">
                {[
                  { prompt: "Evaluate my remaining features", label: "Check Scope creep" },
                  { prompt: "Give me pitch slide structure tips", label: "Explain slide deck layout" },
                  { prompt: "Calculate time estimates for my backlog", label: "Estimate remaining labor hours" },
                ].map((item, i) => (
                  <button
                    key={i}
                    onClick={() => {
                      setChatInput(item.prompt);
                      // Trigger send with slight delay
                      setTimeout(() => {
                        setChatMessages((prev) => [...prev, { sender: "user", text: item.prompt }]);
                        setChatInput("");
                        
                        setTimeout(() => {
                          let botResponse = "I am processing. Our upcoming integrations will estimate this dynamically!";
                          if (item.prompt.includes("features")) {
                            botResponse = `Scope pilot rating: Currently ${completionRate}% complete with ${totalTasks - completedTasks} outstanding. Recommendation: Freeze feature scope and move directly to production code polishing!`;
                          } else if (item.prompt.includes("slide")) {
                            botResponse = "Pitch structure: Keep pages to exactly 5. Showcase: Problem, dynamic pilot prioritizing, tech stack architectures, and live dashboard telemetry.";
                          } else if (item.prompt.includes("estimates")) {
                            botResponse = `Backlog estimate: ${totalTasks - completedTasks} tasks remaining requires roughly ${Math.round((totalTasks - completedTasks) * 2.5)} hours of focused sprint work. Early local backend testing is highly recommended.`;
                          }
                          setChatMessages((prev) => [...prev, { sender: "bot", text: botResponse }]);
                        }, 500);
                      }, 50);
                    }}
                    className="w-full text-left p-3 rounded-xl border border-slate-200 hover:bg-slate-50 transition-colors text-xs font-semibold text-slate-700 flex items-center justify-between cursor-pointer"
                  >
                    <span>{item.label}</span>
                    <Sparkles className="w-3.5 h-3.5 text-blue-500" />
                  </button>
                ))}
              </div>

              <div className="bg-slate-50 p-4 rounded-xl border border-slate-100 text-center">
                <span className="text-[10px] bg-blue-100 text-blue-800 font-bold px-2 py-0.5 rounded-full uppercase">API Telemetry</span>
                <p className="text-[10px] text-slate-400 mt-2">
                  Gemini API & Server side prompts will run securely via back-end routing.
                </p>
              </div>
            </div>
 
          </motion.div>
        )}

      </div>

      {/* Footer */}
      <footer className="bg-white border-t border-slate-200 py-4 mt-auto">
        <div className="max-w-7xl mx-auto px-6 sm:px-8 text-center text-xs text-slate-400">
          DeadlinePilot AI • Built for Google AI Studio Hackathon
        </div>
      </footer>
    </DashboardLayout>
  );
}
